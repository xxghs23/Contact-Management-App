package com.ensah.core.services;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ensah.core.bo.Contact;
import com.ensah.core.dao.ContactDao;


@Service
@Transactional
public class ContactServiceImpl implements ContactService {

	private ContactDao contactDao;

	@Autowired
	public ContactServiceImpl(ContactDao contactDao) {
		this.contactDao = contactDao;
	}



	@Override
	public List<Contact> getContactsByLastName(String lastName) {
		return contactDao.findByLastName(lastName);
	}

	public void addContact(Contact pContact) {
		contactDao.save(pContact);
	}


	public void deleteContact(Long idContact) {
		contactDao.deleteById(idContact);

	}

	@Override
	public Contact searchContact(String lastName) {
		return (Contact) contactDao.getContactBylastName(lastName);
	}


	public Contact getContactById(Long idContact) {
		return contactDao.findById(idContact).orElse(null);

	}

	@Override
	public List<Contact> getAllContacts(String lastName) {
		return null;
	}

	//@Override
	//public List<Contact> getAllContacts(String lastName) {
		//return null;
	//}


	public void updateContact(Contact pContact) {
		contactDao.save(pContact);

	}

	@Override
	public List<Contact> getAllContacts() {
		 return contactDao.findAll();
	}

	/*public Contact getContactByPhoneNumber(String Tel1, String Tel2) {
		Contact contact = ContactRepository.findByTel1(Tel1);
		if (contact == null) {
			contact = ContactRepository.findByTel2(Tel2);
		}
		return contact;
	}*/

	public List<Contact> searchContactByPhoneNumber(String phoneNumber) {
		List<Contact> searchResults = new ArrayList<>();
		searchResults.addAll(contactDao.findByTel1(phoneNumber));
		searchResults.addAll(contactDao.findByTel2(phoneNumber));
		return searchResults;
	}

	public List<Contact> searchContactsBySimilarLastName(String lastName) {
		List<Contact> contacts = getAllContacts(); // Récupérer tous les contacts depuis la source de données

		List<Contact> searchResults = new ArrayList<>();
		int threshold = 2; // Ajustez le seuil en fonction de votre tolérance pour les fautes de frappe

		for (Contact contact : contacts) {
			if (calculateEditDistance(contact.getLastName(), lastName) <= threshold) {
				searchResults.add(contact);
			}
		}

		return searchResults;
	}

	private int calculateEditDistance(String s1, String s2) {
		int m = s1.length();
		int n = s2.length();

		int[][] dp = new int[m + 1][n + 1];

		for (int i = 0; i <= m; i++) {
			dp[i][0] = i;
		}

		for (int j = 0; j <= n; j++) {
			dp[0][j] = j;
		}

		for (int i = 1; i <= m; i++) {
			for (int j = 1; j <= n; j++) {
				if (s1.charAt(i - 1) == s2.charAt(j - 1)) {
					dp[i][j] = dp[i - 1][j - 1];
				} else {
					dp[i][j] = Math.min(dp[i - 1][j - 1], Math.min(dp[i - 1][j], dp[i][j - 1])) + 1;
				}
			}
		}

		return dp[m][n];
	}



}
