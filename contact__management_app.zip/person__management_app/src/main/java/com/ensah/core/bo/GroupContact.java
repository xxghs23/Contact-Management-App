package com.ensah.core.bo;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class GroupContact {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idGroup;

    @Column(nullable = false)
    private String groupName;

    //@OneToMany(mappedBy = "group", cascade = CascadeType.ALL)
    //private List<Contact> contacts = new ArrayList<>();

    @ManyToMany(mappedBy = "groups")
    private List<Contact> contacts = new ArrayList<>();



    // Constructors, getters, and setters

    public GroupContact() {
    }

    public GroupContact(String groupName) {
        this.groupName = groupName;
    }

    public Long getIdGroup() {
        return idGroup;
    }

    public void setIdGroup(Long idGroup) {
        this.idGroup = idGroup;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public List<Contact> getContacts() {
        return contacts;
    }

    public void setContacts(List<Contact> contacts) {
        this.contacts = contacts;
    }

    // Other attributes and relationships

    @Override
    public String toString() {
        return "GroupContact{" +
                "idGroup=" + idGroup +
                ", groupName='" + groupName + '\'' +
                ", contacts=" + contacts +
                '}';
    }
}
