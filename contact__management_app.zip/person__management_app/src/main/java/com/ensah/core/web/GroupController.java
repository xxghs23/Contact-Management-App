package com.ensah.core.web;// Import necessary classes

import com.ensah.core.bo.Contact;
import com.ensah.core.bo.GroupContact;
//import com.ensah.core.bo.GroupContact;
import com.ensah.core.dao.ContactDao;
import com.ensah.core.services.ContactService;
import com.ensah.core.services.GroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.*;

@Controller
public class GroupController {

    @Autowired
    private GroupService groupService;
    @Autowired
    private ContactService contactService;
    @Autowired
    private ContactDao contactDao;

   /* @RequestMapping("/addGroup")
    public String addGroup(@ModelAttribute("groupModel") Group group) {
        groupService.createGroup(group);
        return "redirect:/manageGroups";
    }*/
   /* @RequestMapping("/addGroup")
    public String addGroup(Model model) {
        GroupContact group = new GroupContact(); // Create a new Group object
        groupService.createGroup(group);
        model.addAttribute("groupModel", group); // Add groupModel attribute to the model
        return "addGroup"; // Return the view name
    }*/
    /*@RequestMapping("/addGroup")
    public String addGroup(Model model) {
        GroupContact group = new GroupContact(); // Create a new GroupContact object
        //groupService.createGroup(group);
        model.addAttribute("groupModel", group); // Add groupModel attribute to the model

        return "addGroup"; // Return the name of the view template to render
    }*/

    @GetMapping("/addGroup")
    public String addGroupForm(Model model) {
        GroupContact group = new GroupContact();
        model.addAttribute("groupModel", group);
        return "addGroup";
    }

    @PostMapping("/addGroup")
    public String addGroup(@ModelAttribute("groupModel") GroupContact group) {
        groupService.createGroup(group);
        return "redirect:/manageGroups";
    }

    /*@RequestMapping("/addGroup")
    public String process(@Valid @ModelAttribute("groupModel") GroupContact group, BindingResult bindingResult, Model model) {

        if (bindingResult.hasErrors()) {
            model.addAttribute("errorMsg", "Les données sont invalides.");
        } else {
            groupService.addGroup(group);
            model.addAttribute("infoMsg", "Contact ajouté avec succès");

        }
        model.addAttribute("contactList", groupService.getAllGroups()); // Mettre la liste des personnes dans le modèle

        return "addGroup";

    }*/



    @RequestMapping(value = "/updateGroupForm/{groupId}", method = RequestMethod.GET)
    public String updateGroupForm(@PathVariable(name = "groupId") Long groupId, Model model) {
        GroupContact group = groupService.getGroupById(groupId);
        model.addAttribute("groupModel", group);
        return "updateGroupForm";
    }

    @RequestMapping(value = "/updateGroup", method = RequestMethod.POST)
    public String updateGroup(@ModelAttribute("groupModel") GroupContact group) {
        groupService.updateGroup(group);
        return "redirect:/manageGroups";
    }

    @RequestMapping(value = "/deleteGroup/{groupId}", method = RequestMethod.GET)
    public String deleteGroup(@PathVariable("groupId") Long groupId) {
        groupService.deleteGroup(groupId);
        return "redirect:/manageGroups";
    }

    @RequestMapping("/manageGroups")
    public String manageGroups(Model model) {
        List<GroupContact> groupList = groupService.getAllGroups();

        // Sort the list of groups by group name
        Collections.sort(groupList, Comparator.comparing(GroupContact::getGroupName));

        model.addAttribute("groupList", groupList);

        return "listGroups";
    }

    /*@PostMapping("/addGroupContact/{groupId}/{idContact}")
    public String addContactToGroup(@PathVariable("groupId") Long groupId, @PathVariable("idContact") Long idContact) {
        groupService.addContactToGroup(groupId, idContact);
        return "redirect:/manageGroups";
    }*/

    /*@PostMapping("/addGroupContact/{groupId}/{idContact}")
    public String addContactToGroup(@PathVariable("contactId") Long contactId, @RequestParam("groupId") Long groupId) {
        // Add the contact to the group with the given IDs
        groupService.addContactToGroup(groupId, contactId);
        return "redirect:/manageGroups";
    }*/
    /*@GetMapping("/addGroupContact/{groupId}/{contactId}")
    public String addContactToGroup(@PathVariable("groupId") Long groupId, @PathVariable("contactId") Long contactId ,Model model) {
        model.addAttribute("groupId", groupId);
        model.addAttribute("listcontact",GroupContact.getContacts());
        return "listGroups";
    }*/
    /*@RequestMapping("/addContactToGroup/{contactId}/{groupId}")
    public String addContactToGroup(@PathVariable("groupId") Long groupId, @PathVariable("contactId") Long contactId ,Model model) {
        // Add the contact to the group
        groupService.addContactToGroup(groupId, contactId);
        //List<Contact> contactList = contactService.getAllContacts();
       // GroupContact group = groupService.getGroupById(groupId);
        //model.addAttribute("contactList", contactList);
        //model.addAttribute("group", group);
        // Add a success message to the model
        GroupContact group = groupService.getGroupById(groupId);
        String groupName = group.getGroupName();

        // Add a success message to the model
        String successMessage = "Contact added successfully to the group: " + groupName;
        model.addAttribute("successMessage", successMessage);

        // Redirect to a relevant page or display a success message
        return "listGroups";
    }*/

    /*@PostMapping("/addContactToGroup")
    public String addContactToGroup(@RequestParam("groupId") Long groupId, @RequestParam("contactId") Long contactId, Model model) {
        // Add the contact to the group
        groupService.addContactToGroup(groupId, contactId);

        // Get the group and contact details for displaying the success message
        GroupContact group = groupService.getGroupById(groupId);
        Contact contact = contactService.getContactById(contactId);

        // Create the success message
        String successMessage = "Contact '" + contact.getFirstName() + " " + contact.getLastName() + "' added successfully to the group: " + group.getGroupName();
        model.addAttribute("successMessage", successMessage);

        // Redirect to the list of groups or any other relevant page
        return "redirect:/manageGroups";
    }*/

    @PostMapping("/addContactToGroup")
    public String addContactToGroup(@RequestParam("groupId") Long groupId, @RequestParam("contactId") Long contactId, Model model) {
        try {
            // Add the contact to the group
            groupService.addContactToGroup(groupId, contactId);

            // Get the group and contact details for displaying the success message
            GroupContact group = groupService.getGroupById(groupId);
            Contact contact = contactService.getContactById(contactId);

            // Create the success message
            String successMessage = "Contact '" + contact.getFirstName() + " " + contact.getLastName() + "' added successfully to the group: " + group.getGroupName();
            model.addAttribute("successMessage", successMessage);

            // Redirect to the list of groups or any other relevant page
            return "redirect:/manageGroups";
        } catch (IllegalArgumentException e) {
            // Handle the case where the contact is already associated with the group
            String errorMessage = "Contact is already associated with the group";
            model.addAttribute("errorMessage", errorMessage);
            // Redirect to an error page or any other relevant page
            return "error";
        }
    }






    @PostMapping("/manageGroups/search")
    public String searchGroupByName(@RequestParam("searchValue") String searchValue, Model model) {
        // Effectuer la recherche du groupe par nom
        List<GroupContact> groups = (List<GroupContact>) groupService.getGroupByName(searchValue);

        // Ajouter les groupes au modèle
        model.addAttribute("groupList", groups);

        return "listGroups"; // Rediriger vers la page de liste des groupes avec les résultats de la recherche
    }

    /*@GetMapping("/selectGroupForm")
    public String selectGroupForm(@PathVariable("contactId") Long contactId, Model model) {
        List<GroupContact> groups = groupService.getAllGroups();
        model.addAttribute("groups", groups);
        model.addAttribute("contactId", contactId);
        return "selectGroup"; // Return the view where the user can select the group
    }*/

    /*@GetMapping("/selectGroupForm/{contactId}")
    public String selectGroupForm(@PathVariable("contactId") Long contactId, Model model) {
        // Add the contact ID to the model
        model.addAttribute("contactId", contactId);

        // Retrieve the list of groups from the database
        List<GroupContact> groups = groupService.getAllGroups();
        model.addAttribute("groups", groups);

        // Return the name of the JSP file to be displayed
        return "selectGroup";
    }*/

    @GetMapping("/selectGroupForm/{contactId}")
    public String selectGroupForm(@PathVariable("contactId") Long contactId, Model model) {
        // Pass the contact ID as a model attribute
        model.addAttribute("contactId", contactId);

        // Retrieve the list of groups from the database
        List<GroupContact> groups = groupService.getAllGroups();
        model.addAttribute("groups", groups);

        // Create a new instance of the Contact model attribute for form binding
        model.addAttribute("contactModel", new Contact());

        // Return the name of the JSP file to be displayed
        return "selectGroup";
    }



    /*@PostMapping("/addGroup/{contactId}/{groupId}")
    public String addContactToSelectedGroup(@PathVariable("contactId") Long contactId, @PathVariable("groupId") Long groupId) {
        groupService.addContactToGroup(groupId, contactId);
        return "redirect:/listContacts"; // Redirect back to the contact list or any other desired page
    }*/






    // Other existing methods
}
