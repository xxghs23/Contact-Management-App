package com.ensah.core.dao;
import java.util.List;
import com.ensah.core.bo.Contact;
public interface CustomizedContactDao {
    //List<Contact> getContactBylastName(String lastName);

}

