package com.ensah.core.dao;

import com.ensah.core.bo.GroupContact;
import com.ensah.core.bo.GroupContact;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GroupRepository extends JpaRepository<GroupContact, Long> {
    GroupContact findByGroupName(String groupName);

    List<GroupContact> findAllByGroupName(String groupName);
}
