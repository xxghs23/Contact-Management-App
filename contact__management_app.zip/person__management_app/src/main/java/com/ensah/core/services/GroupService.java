package com.ensah.core.services;

import com.ensah.core.bo.GroupContact;
import com.ensah.core.bo.Contact;

import java.util.List;

public interface GroupService {
    List<GroupContact> getAllGroups();
    GroupContact createGroup(GroupContact group);
    void updateGroup(GroupContact group);
    //void addGroup(GroupContact group);
    void deleteGroup(Long groupId);
    //Group getGroupById(Long groupId);


    GroupContact getGroupById(Long groupId);
    void addContactToGroup(Long groupId, Long contact);

    List<GroupContact> getGroupByName(String groupName);


    void removeContactFromGroup(Long groupId, Contact contact);
}

