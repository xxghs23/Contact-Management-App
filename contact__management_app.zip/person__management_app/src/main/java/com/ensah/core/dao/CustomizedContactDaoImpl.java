package com.ensah.core.dao;

import java.util.List;

import com.ensah.core.bo.Contact;
import com.ensah.genericdao.JPAHibernateGenericDAOImpl;

public class CustomizedContactDaoImpl extends JPAHibernateGenericDAOImpl<Contact, Long> implements CustomizedContactDao {

   /// @Override
    //public List<Contact> getContactBylastName(String lastName) {
      //  return null;}
}
