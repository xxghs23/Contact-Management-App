package com.ensah.core.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ensah.core.bo.Contact;
import org.springframework.stereotype.Repository;

@Repository
public interface ContactDao extends JpaRepository<Contact, Long>, CustomizedContactDao {
    //List<Contact> findBylastName(String lastName);

    List<Contact> findByLastName(String lastName);


    List<Contact> getContactBylastName(String lastName);

    List<Contact> findByTel1(String tel1);

    List<Contact> findByTel2(String tel2);
    //List<Contact> getAllContacts();


}
