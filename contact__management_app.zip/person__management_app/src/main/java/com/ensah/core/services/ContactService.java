package com.ensah.core.services;

import java.util.List;

import com.ensah.core.bo.Contact;

/**
 * Interface du Service
 * 
 * @author T. BOUDAA
 *
 */
public interface ContactService {

	List<Contact> getContactsByLastName(String lastName);

	public void addContact(Contact pContact);

	public void updateContact(Contact pContact);

	public List<Contact> getAllContacts();

	public void deleteContact(Long id);

	Contact searchContact(String lastName);

	public Contact getContactById(Long id);

	List<Contact> getAllContacts(String lastName);

	List<Contact> searchContactByPhoneNumber(String searchValue);

	//Contact getContactBytel1(String tel1);

	//Contact getContactByPhoneNumber(String phoneNumber);


	//Contact searchContactsByLastName(String );
}
