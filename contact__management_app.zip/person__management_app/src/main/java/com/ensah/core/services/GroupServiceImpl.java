package com.ensah.core.services;

import com.ensah.core.bo.GroupContact;
import com.ensah.core.bo.Contact;
import com.ensah.core.dao.ContactDao;
import com.ensah.core.dao.GroupRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GroupServiceImpl implements GroupService {

    private final GroupRepository groupRepository;

    private ContactDao contactDao;

    @Autowired
    public GroupServiceImpl(GroupRepository groupRepository, ContactDao contactDao) {
        this.groupRepository = groupRepository;
        this.contactDao = contactDao;
    }


    @Override
    public List<GroupContact> getAllGroups() {
        return groupRepository.findAll();
    }


    @Override
    public GroupContact createGroup(GroupContact group) {
        return groupRepository.save(group);
    }

    @Override
    public void updateGroup(GroupContact group) {
        GroupContact existingGroup = getGroupById(group.getIdGroup());
        existingGroup.setGroupName(group.getGroupName());
        // Update other fields as needed
        groupRepository.save(existingGroup);
    }


    @Override
    public void deleteGroup(Long groupId) {
        GroupContact group = getGroupById(groupId);
        groupRepository.delete(group);
    }


    @Override
    public GroupContact getGroupById(Long groupId) {
        return groupRepository.findById(groupId).orElseThrow(() -> new IllegalArgumentException("Invalid group ID: " + groupId));
    }

    /*@Override
    public void addContactToGroup(Long groupId, Contact contact) {
        GroupContact group = getGroupById(groupId);
        group.getContacts().add(contact);
        groupRepository.save(group);
    }*/
    public void addContactToGroup(Long groupId, Long contactId) {
        GroupContact group = groupRepository.findById(groupId).orElse(null);
        Contact contact = contactDao.findById(contactId).orElse(null);

        if (group != null && contact != null && !group.getContacts().contains(contact)) {
            group.getContacts().add(contact);
            //contact.setGroup(group);
            contact.addGroup(group);
            groupRepository.save(group);

            //String successMessage = "Contact added successfully to the group: " + group.getGroupName();
            //group.setSuccessMessage(successMessage);
        }else {
            // Handle the case where the contact is already associated with the group
            // You can throw an exception, show an error message, or take any other desired action
            // For example:
            throw new IllegalArgumentException("Contact is already associated with the group");
        }
    }

    @Override
    public List<GroupContact> getGroupByName(String groupName) {
        return groupRepository.findAllByGroupName(groupName);
    }




    @Override
    public void removeContactFromGroup(Long groupId, Contact contact) {
        GroupContact group = getGroupById(groupId);
        group.getContacts().remove(contact);
        groupRepository.save(group);
    }

    // Implement other group-related methods as needed
}

