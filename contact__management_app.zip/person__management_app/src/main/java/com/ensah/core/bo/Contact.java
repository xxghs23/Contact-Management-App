package com.ensah.core.bo;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import java.util.ArrayList;
import java.util.List;


@Entity
public class Contact {

	/*
	 * Documentation : 
	 * @NotNull: a constrained CharSequence, Collection, Map, or Array is valid as
	 * long as it's not null, but it can be empty
	 * 
	 * @NotEmpty: a constrained CharSequence, Collection, Map, or Array is valid as
	 * long as it's not null and its size/length is greater than zero
	 * 
	 * @NotBlank: a constrained String is valid as long as it's not null and the
	 * trimmed length is greater than zero
	 */

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idContact;

	public Long getIdContact() {
		return idContact;
	}

	public void setIdContact(Long idContact) {
		this.idContact = idContact;
	}

	@NotBlank(message = "This field is required")
	private String firstName;

	@NotBlank(message = "This field is required")
	private String lastName;

	public String getTel1() {
		return tel1;
	}

	public void setTel1(String tel1) {
		this.tel1 = tel1;
	}

	@NotNull(message = "This field is required")
	@Digits(integer = 10, message = "tel must contain 10 numbers", fraction = 1)
	private String tel1;


	public String getTel2() {
		return tel2;
	}

	public void setTel2(String tel2) {
		this.tel2 = tel2;
	}



	@NotNull(message = "This field is required")
	@Digits(integer = 10, message = "tel must contain 10 numbers", fraction = 0)
	private String tel2;

	@Email(message = "Enter a valid email_pers" + "")
	@NotBlank(message = "This field is required")
	private String email_pers
			;

	public String getEmail_pro() {
		return email_pro;
	}

	public void setEmail_pro(String email_pro) {
		this.email_pro = email_pro;
	}

	@Email(message = "Enter a valid email_pers" + "")
	@NotBlank(message = "This field is required")
	private String email_pro;


	@NotBlank(message = "This field is required")
	private String address;

	@NotBlank(message = "This field is required")
	private String gender;

	public Long getidContact() {
		return idContact;
	}

	public void setidContact(Long idContact) {
		this.idContact = idContact;
	}



	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public String getemail_pers() {
		return email_pers
				;
	}

	public void setemail_pers
			(String email_pers
			) {
		this.email_pers
				= email_pers
		;
	}

	public String getEmail_pers() {
		return email_pers;
	}

	public void setEmail_pers(String email_pers) {
		this.email_pers = email_pers;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "Contact{" +
				"idContact=" + idContact +
				", firstName='" + firstName + '\'' +
				", lastName='" + lastName + '\'' +
				", Tel1=" + tel1 +
				", Tel2=" + tel2 +
				", email_pers='" + email_pers + '\'' +
				", email_pro='" + email_pro + '\'' +
				", address='" + address + '\'' +
				", gender='" + gender + '\'' +
				'}';
	}

	//@ManyToMany
	//private List<GroupContact> groups = new ArrayList<>();
	@ManyToMany
	@JoinTable(
			name = "contact_group",
			joinColumns = @JoinColumn(name = "contact_id"),
			inverseJoinColumns = @JoinColumn(name = "group_id")
	)
	private List<GroupContact> groups = new ArrayList<>();


	public List<GroupContact> getGroups() {
		return groups;
	}

	public void setGroups(List<GroupContact> groups) {
		this.groups = groups;
	}
	public void addGroup(GroupContact group) {
		groups.add(group);
		group.getContacts().add(this);
	}

	public void removeGroup(GroupContact group) {
		groups.remove(group);
		group.getContacts().remove(this);
	}


	}