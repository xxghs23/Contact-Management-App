package com.ensah.core.web;

import java.util.*;

import com.ensah.core.bo.GroupContact;
import com.ensah.core.services.ContactServiceImpl;
import com.ensah.core.services.GroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import com.ensah.core.bo.Contact;
import com.ensah.core.services.ContactService;

import javax.annotation.PostConstruct;
import javax.servlet.ServletContext;
import javax.validation.Valid;

@Controller
public class ContactController {

	@Autowired
	private ContactServiceImpl contactService;
	@Autowired
	private GroupService groupService;// Injection du service metier ici

	@Autowired
	private ServletContext appContext;

	//private Map<String, String> countryList = new HashMap<String, String>(); // Contient les pays à afficher dans la vue

	/*public ContactController() {
		countryList.put("Morocco", "Morocco");
		countryList.put("France", "France");
		countryList.put("Spain", "Spain");

	}*/

	@PostConstruct
	public void init() {
	
	}

	@RequestMapping("/showForm")
	public String showForm(Model model) {

		model.addAttribute("contactModel", new Contact()); // Ajouter un objet Personne vide comme attribut du modèle
		//model.addAttribute("countryList", countryList); // Ajouter la liste des pays comme attribut du modèle
		model.addAttribute("contactList", contactService.getAllContacts());// Ajouter la liste des personnes comme attribut
																		// du modèle

		return "form"; // On retourne le nom de la vue
	}

	// on récupère la valeur du path variable idPerson dans le paramètre annotée
	// @PathVariable
	// Ici puisque nous avons utilisé le même nom pour le pathVariable et le
	// paramètre de la méthode, nous pouvons
	// remplacer @PathVariable(name = "idPerson") par @PathVariable
	/*@RequestMapping(value = "/updateContactForm/{contactId}", method = RequestMethod.GET)
	public String updateContactForm(@PathVariable(name = "contactId") Long idContact, Model model) {
		Contact contact = contactService.getContactById(idContact);
		contactService.updateContact(contact);
		model.addAttribute("contactModel", contact);
		return "redirect:/manageContacts";
	}*/

	/*@RequestMapping(value = "/updateContact", method = RequestMethod.POST)
	public String updateContact(@ModelAttribute("contactModel") Contact pContact,Model model) {
		contactService.updateContact(pContact);
		model.addAttribute("contactList", contactService.getAllContacts());
		return "redirect:/manageContacts";
	}*/

	/*@RequestMapping(value = "/updateContact", method = RequestMethod.POST)
	public String updateContact(@ModelAttribute("contactModel") Contact contact,Model model) {
		contactService.updateContact(contact);

		// Retrieve the updated contact object from the database
		Contact updatedContact = contactService.getContactById(contact.getIdContact());

		// Set the updated contact object as a model attribute
		model.addAttribute("contactModel", updatedContact);

		// Return the view name of the contact form
		return "redirect:/manageContacts";
	}*/

	@RequestMapping(value = "/updateContactForm/{idContact}", method = RequestMethod.GET)
	public String updateContactForm(@PathVariable(name = "idContact") int idContact, Model model) {

		model.addAttribute("contactModel", contactService.getContactById(Long.valueOf(idContact)));
		//model.addAttribute("countryList", countryList);

		return "updateForm";
	}
	@RequestMapping(value = "/updateContact", method = RequestMethod.POST)
	public String updateContact(@Valid @ModelAttribute("contactModel") Contact contact, BindingResult bindingResult, Model model) {

		// If there are validation errors
		if (bindingResult.hasErrors()) {
			return "updateForm";
		}

		// Update the contact
		contactService.updateContact(contact);
		//model.addAttribute("contactList",contactService.getAllContacts());

		// Redirect to the contact list page
		return "redirect:/manageContacts";
	}


	@RequestMapping("/addContact")
	public String process(@Valid @ModelAttribute("contactModel") Contact contact, BindingResult bindingResult,
			Model model) {
		//model.addAttribute("countryList", countryList);

		if (bindingResult.hasErrors()) {
			model.addAttribute("errorMsg", "Les données sont invalides.");
		} else {
			contactService.addContact(contact);
			model.addAttribute("infoMsg", "Contact ajouté avec succès");

		}
		model.addAttribute("contactList", contactService.getAllContacts()); // Mettre la liste des personnes dans le modèle

		return "form";

	}

	@RequestMapping("/manageContacts")
	public String manageContacts(Model model) {

		Long groupId = 1L;

		List<Contact> contactList = contactService.getAllContacts();
		GroupContact group = groupService.getGroupById(groupId);
		// Sort the list of contacts by last name
		Collections.sort(contactList, Comparator.comparing(Contact::getLastName));

		model.addAttribute("contactList", contactList);
		model.addAttribute("group", group);

		//model.addAttribute("contactList", contactService.getAllContacts()); // Mettre la liste des personnes dans le modèle

		return "listContacts";
	}

	/*@RequestMapping("manageContacts")
	public String manageContacts(Model model, @RequestParam("groupId") int groupId) {
		List<Contact> contactList = contactService.getAllContacts();
		GroupContact group = groupService.getGroupById((long) groupId);
		// Sort the list of contacts by last name
		Collections.sort(contactList, Comparator.comparing(Contact::getLastName));

		model.addAttribute("contactList", contactList);
		model.addAttribute("group", group);

		return "listContacts";
	}*/



	@RequestMapping(value = "/deleteContact/{idContact}", method = RequestMethod.GET)
	public String delete(@PathVariable("idContact") Long idContact, RedirectAttributes redirectAttributes) {
		//contactService.deleteContact(Long.valueOf(idContact));
		contactService.deleteContact(idContact);
		redirectAttributes.addFlashAttribute("successMsg", "Contact deleted successfully");
		return "redirect:/manageContacts";
		}


		// Behind the scenes, RedirectView will trigger a
		// HttpServletResponse.sendRedirect() – which will perform the actual redirect.
		//return new RedirectView(appContext.getContextPath() + "/manageContacts");

		// return "redirect:/manageContacts";
		//return "manageContacts";}


	/*@PostMapping(value = "searchContact")
	public String searchContact(@RequestParam("lastName") String lastName, Model model) {
		List<Contact> searchResults = contactService.getContactsByLastName(lastName);
		model.addAttribute("contactList", searchResults);
		return "listContacts";}*/
	/*@PostMapping("/searchContact")
	public String searchContact(@RequestParam(value = "searchType", required = false) String searchType,
								@RequestParam(value = "searchValue", required = false) String searchValue,
								Model model) {
		List<Contact> searchResults = new ArrayList<>();

		if (searchType != null && searchValue != null) {
			if (searchType.equals("phoneNumber")) {
				searchResults = contactService.searchContactByPhoneNumber(searchValue);
			} else if (searchType.equals("lastName")) {
				searchResults = contactService.getContactsByLastName(searchValue);
			}
		}

		model.addAttribute("contactList", searchResults);
		return "listContacts";
	}*/

	@PostMapping("/searchContact")
	public String searchContact(@RequestParam(value = "searchType", required = false) String searchType,
								@RequestParam(value = "searchValue", required = false) String searchValue,
								Model model) {
		List<Contact> searchResults = new ArrayList<>();

		if (searchType != null && searchValue != null) {
			if (searchType.equals("phoneNumber")) {
				searchResults = contactService.searchContactByPhoneNumber(searchValue);
			} else if (searchType.equals("lastName")) {
				// Perform the enhanced search by name
				searchResults = contactService.searchContactsBySimilarLastName(searchValue);
			}
		}

		model.addAttribute("contactList", searchResults);
		return "listContacts";
	}



	/*@PostMapping("/searchContact")
	public String searchContact(@RequestParam("phoneNumber") String phoneNumber, Model model) {
		Contact contact = contactService.getContactByPhoneNumber(phoneNumber);
		model.addAttribute("contact", contact);
		return "searchResult";
	}*/





	/*@GetMapping("/groups/{contactId}")
	public String showForm(@PathVariable Long contactId, Model model) {
		Contact contact = contactService.getContactById(contactId);
		model.addAttribute("contact", contact);
		return "group";
	}*/

	@ExceptionHandler(Exception.class)
	public String handleException(Exception ex, Model model) {
		// Perform any necessary error handling, logging, or custom processing
		// You can customize the error message or add additional information to the model

		model.addAttribute("errorMessage", "An error occurred: " + ex.getMessage());

		// Return the appropriate error view
		return "error";
	}




}
